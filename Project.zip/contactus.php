<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email =$_POST['email'];
    $description=$_POST['message'];
    if(mysqli_query($conn, "INSERT INTO message(name,email,message,DateInserted) VALUES('" . $name . "', '" . $email . "', '" .$description. "',UTC_TIMESTAMP())")) {
        $success_message = "We've recieved your message, we'll contact you ASAP.";
    } else {
        echo mysqli_error($conn);
        $error_message = "Error!! Please try again later!";
    }
}
?>
<head>
	<title>Contact</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/contact.css">
    <link rel="stylesheet" href="css/landing.css">
</head>
<?php
include_once("navs/allnav.php");
?>
<div class="containerr">  
  <form id="contact" action="" method="post">
    <h3> Contact Form</h3>
    <h4>Contact us for your queries</h4>
    <fieldset>
      <input placeholder="Your name" name="name" type="text" tabindex="1" required autofocus>
    </fieldset>
    <fieldset>
      <input placeholder="Your Email Address" name="email" type="email" tabindex="2" required>
    </fieldset>
    <fieldset>
      <textarea placeholder="Type your message here...." tabindex="5" name="message" required></textarea>
    </fieldset>
    <fieldset>
      <button name="submit" type="submit" id="contact-submit" data-submit="...Sending">Submit</button>
    </fieldset>
    <span class="text-danger"><?php if (isset($success_message)) { echo $success_message; } ?></span>
    <span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
    <!--<p class="copyright">Designed by <a href="https://skyinc.000webhostapp.com/" target="_blank" title="Colorlib">Skyinsurance</a></p>-->

  </form>

  <section>
  <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.82408455857!2d73.02153911437605!3d19.02747185844185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c3b8c6e17cef%3A0x5dbe77a014d910dc!2sSector%2019A%20Nerul%20Rd%2C%20Nerul%20East%2C%20Sector%2019A%2C%20Nerul%2C%20Navi%20Mumbai%2C%20Maharashtra%20400706!5e0!3m2!1sen!2sin!4v1569431343091!5m2!1sen!2sin" width="400" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</section>

</div>