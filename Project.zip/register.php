<?php
include_once("db_connect.php");
session_start();
$email = $_SESSION['email'];
$error = false;
if (isset($_POST['signup'])) {
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']);	
	if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
		$error = true;
		$uname_error = "Name must contain only alphabets and space";
	}

	if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
		$error = true;
		$email_error = "Please Enter Valid Email ID";
	}

	if(strlen($password) < 6) {
		$error = true;
		$password_error = "Password must be minimum of 6 characters";
	}

	if($password != $cpassword) {
		$error = true;
		$cpassword_error = "Password and Confirm Password doesn't match";
	}

	if (!$error) {
		if(mysqli_query($conn, "INSERT INTO users(user, email, pass) VALUES('" . $name . "', '" . $email . "', '" . md5($password) . "')")) {
		    $_SESSION['name']=$_POST['name'];
			$success_message = "Successfully Registered! <a href='login.php'>Click here to Login</a>";
		} else {
			$error_message = "Error in registering...Please try again later!";

		}

	}

}







?>

<style>

body {

  font-family: Arial, Helvetica, sans-serif;

  background-color:white;

}



* {

  box-sizing: border-box;

}



/* Add padding to containers */

.container {

  padding: 16px;

  margin: auto;

  width:400px;

  background-color: white;

}



/* Full-width input fields */

input[type=text], input[type=password] {

  width: 100%;

  padding: 15px;

  margin: 5px 0 22px 0;

  display: inline-block;

  border: none;

  background: #f1f1f1;

  border-radius: 50px;

}



input[type=text]:focus, input[type=password]:focus {

  background-color: #ddd;

  outline: none;

}



/* Overwrite default styles of hr */

hr {

  border: 1px solid #f1f1f1;

  margin-bottom: 25px;

}



/* Set a style for the submit button */

.registerbtn {

  background-color: #4CAF50;

  color: white;

  padding: 16px 20px;

  margin: 8px 0;

  border: none;

  cursor: pointer;

  width: 100%;

  opacity: 0.9;

  box-shadow: 4px 4px 8px grey;

  border-radius: 50px;

}



.registerbtn:hover {

  opacity: 1;

}



/* Add a blue text color to links */

a {

  color: dodgerblue;

}



/* Set a grey background color and center the text of the "sign in" section */

.signin {

  background-color: #f1f1f1;

  text-align: center;

}

</style>
<script language="javascript">

function checkEmail() {

    var email = document.getElementById('txtEmail');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
    return false;
 }
}</script>



<div class="container">

<h2>Sign-Up</h2>	

	<div class="row">

		<div class="col-md-4 col-md-offset-4 well">

			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">

				

					

					<div class="form-group">

						<label for="name">Name</label>

						<input type="text" name="name" placeholder="Enter Full Name" required value="<?php if($error) echo $name; ?>" class="form-control" />

						<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>

					</div>					

					<div class="form-group">

						<label for="name">Email</label>

						<input type="text" id='txtEmail' name="email" placeholder="Email" required value="<?php echo $email;?>" class="form-control" />

						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>

					</div>

					<div class="form-group">

						<label for="name">Password</label>

						<input type="password" name="password" placeholder="Password" required class="form-control" />

						<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>

					</div>

					<div class="form-group">

						<label for="name">Confirm Password</label>

						<input type="password" name="cpassword" placeholder="Confirm Password" required class="form-control" />

						<span class="text-danger"><?php if (isset($cpassword_error)) echo $cpassword_error; ?></span>

					</div>

					<div class="form-group">

						<input type="submit" name="signup"  value="Sign Up" class="registerbtn" onclick='Javascript:checkEmail();'/>

					</div>

				

			</form>

			<span class="text-success"><?php if (isset($success_message)) { echo $success_message; } ?></span>

			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>

		</div>

	</div>

	<div class="row">

		<div class="col-md-4 col-md-offset-4 text-center">	

		Already Registered? <a href="login.php">Login Here</a>

		</div>

	</div>	

</div>

