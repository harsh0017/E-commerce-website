<?php
session_start();
?>
<!DOCTYPE html>
<head>
<title>Skyinsurance</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/dlanding.css">
<style>
body {
  font-family: consolas;
  background-color: rgb(33, 33, 33);
}
.navbar {
  overflow: hidden;
  background-color: #333;
}
.navbar a {
  float: right;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}
.dropdown {
  float: right;
  overflow: hidden;
}
.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}
p{
	margin:10px;
	color: white;
	font-family: inherit;
	float:left;
}
.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}
.dropdown-content a:hover {
  background-color: #ddd;
}
.dropdown:hover .dropdown-content {
  display: block;
}
@media screen and (max-width: 500px) {
  .navbar a {
    float: none;
    display: block;
  }
}
@media screen and (max-width: 500px) {
  .dropdown-content a,dropdown-content  {
    float: none;
    display: block;
  }
}
.imgtwo {
  display: block;
  margin-left: auto;
  margin-right: auto;
}
</style>
</head>
<body>
<div class="navbar">
    <?php
    if (isset($_SESSION['admin'])){
      $username=$_SESSION['user_name'];
      echo  '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="adminreal.php">Dashboard</a></div>
    </div> ';
 }
 elseif(isset($_SESSION['user_name'])){
      $username=$_SESSION['user_name'];
      echo '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="mypurchase.php" >My Products</a></div>
    </div> ';
      }
    else{
      echo '<div class="dropdown" >
      <button class="dropbtn">Login 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="login.php">User</a>
        <a href="adminlogin.php">Admin</a>
      </div>
    </div> 
      <a href="registernew.php">Signup</a>';
      }
	?>
  <a href="aboutus.php">Aboutus</a>
  <a href="contactus.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a class="active" href="https://skyinc.000webhostapp.com/"><i class="fa fa-fw fa-home"></i> Home</a> 
	<p>SKYINSURANCE</p>
    
   
    </div>
  </div> 
</div>
			<div id="second">
				<h1 id="x" style="text-align: center;">India's Largest Online Insurance Aggregator</h1>
			</div>



			<div id="third">
					<div class="card">
				  	<img src="http://imgs-info.ru/2019/10/09/term2.jpg" alt="Avatar" id="term" class="pointer" onclick="location.href='term.php'">
				  	<div class="container" >
				    <h4 style="color: white;font-size: 20px;text-align: center;"><b>Term Insurance</b></h4> 				     
				  	</div>
					</div>
					<div class="card">
				  	<img src="http://imgs-info.ru/2019/10/09/health2.jpg" alt="Avatar" id="health" class="pointer" onclick="location.href='products.php'">
				  	<a href="healthinsurance.html"></a>

				  	<div class="container">

				    <h4 style="color: white;font-size: 20px;text-align: center; "><b>Health Insurance</b></h4> 			     
				  	</div>
					</div>
					<div class="card">
				  	<img src="http://imgs-info.ru/2019/10/09/travel3.jpg" alt="Avatar" id="car" class="pointer" onclick="location.href='vehicle.php'">
				  	<div class="container">
				    <h4 style="color: white;font-size: 20px;text-align: center;"><b>Travel Insurance</b></h4> 				     
				  	</div>
					</div>
</div>
<img style="border-radius:1px;width:100%;" src="imagess/image.JPG" alt="Statistics">
<br>
<br>
<img onclick="location.href='https://store.google.com/in/product/google_home_mini'" style="border-radius:1px;display: block;margin-left: auto;margin-right: auto;" src="http://imgs-info.ru/2019/10/24/10172019-002033650-BannerA_728X90_Music.gif">

<p id="cpy">&copy; 2019 skyinsurance All Rights Reserved<p>						

</div>

</body>

</html>