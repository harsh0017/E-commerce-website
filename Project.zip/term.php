<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['buynow'])) 
{
if(!isset($_SESSION['user_name']))
{

  echo '<script>
  alert("Please Login to continue.");
  </script>';
  }
  else {
    $emailid=$_SESSION['emailid'];
    $result=mysqli_query($conn, "SELECT email from purchased where email = '" . $emailid. "' and pname = '" .$_POST['name']. "'");
    if ($row = mysqli_fetch_array($result)) {
      echo '<script>
  alert("You have already purchased the product.");
  </script>';
    }
    elseif(mysqli_query($conn, "INSERT INTO purchased(email,pname,price,PurchaseDate) VALUES('" .$emailid. "', '" .$_POST['name']. "', '" .$_POST['price']. "',UTC_TIMESTAMP())")) {
      echo '<script>
      alert("Item Purchased successfully!");
      </script>';
       /* header("Location:afterbuynow.php");*/
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/landing.css">
   <!--  <link rel="stylesheet" href="css/main.css"> -->
    <link rel="stylesheet" href="css/product.css">
    <!--<link rel="stylesheet" href="css/landingtwo.css">-->
</head>
<style>
  body{
    background-color:rgb(33,33,33);
  }
  </style>
<body>
<?php
include_once("navs/allnav.php");
?>
<?php
$result=mysqli_query($conn,"SELECT * FROM term;");
if ($result) {
    while($row = mysqli_fetch_assoc($result))
    {
      $name=$row['pname'];
      $price=$row['price'];
      $des=$row['pdesc'];
      $image=$row['image'];
      // <button>'.$text.'</button>
      $text="Buy now";
        echo '<div class="pcard">
        <img src="'.$image.'" alt="Denim Jeans" style="width:100%">
              <h3>'.$name.'</h3>
              <h2 class="price">'.$price.'&#8377;</h2>
              <h4>'.$des.'</h4>
              <form role="form" action="'.$_SERVER["PHP_SELF"].'" method="post" name="buynowform">
               <input type="hidden" value="'.$name.'"  name="name" id="name"/>
               <input type="hidden" value="'.$price.'" name="price" id="price"/>
               <input type="submit" name="buynow" value="Buy Now"  />
               </form>
              </div>';
              
      
    }
  }
   else {
      $error_message = "Can't Fetch data. Try again later!!";
  }
?>
</html>