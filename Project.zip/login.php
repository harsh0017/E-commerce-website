<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['login'])) {
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$result = mysqli_query($conn, "SELECT * FROM users WHERE email = '" . $email. "' and pass = '" . md5($password). "'");
	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['user_id'] = $row['uid'];
    $_SESSION['user_name'] = $row['user'];
    $_SESSION['emailid'] = $row['email'];
		header("Location: index.php");
	} else {
		$error_message = "Incorrect Email or Password!!!";
	}
}
?>
<script>
function showHint(str) {
    if (str.length == 0) { 
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText ;
            }
        }
        xmlhttp.open("GET", "gethint.php?qa=" + str, true);
        xmlhttp.send();
    }
}
</script>
<html>
<head>
	<title>Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/landing.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/nav.css">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-radius: 50px;
  
}
input[type=text]:focus, input[type=password]:focus {
background-color: #ddd;
outline: none;
}
.button {
  background-color:black;
  color: white;
  border-radius: 50px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  box-shadow: 4px 3px 6px black;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  margin: auto;
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 300px;
  height: 300px;
  border-radius: 50%;
}

.container {
  margin: auto;
  padding: 16px;
  width:400px;


}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>


<div class="navbar">
   <?php
   echo '<div class="dropdown" >
   <button class="dropbtn">Sign-up 
     <i class="fa fa-caret-down"></i>
   </button>
   <div class="dropdown-content">
     <a href="registernew.php">User</a>
     <a href="adotp.php">Admin</a>
   </div>
 </div>';
      echo '<div class="dropdown" >
      <button class="dropbtn">Login 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="adminlogin.php">Admin</a>
      </div>
    </div>';
	?>
  <a href="aboutus.php">Aboutus</a>
  <a href="contactus.php"><i class="fa fa-fw fa-envelope"></i>Contact</a> 
  <a class="active" href="https://skyinc.000webhostapp.com/"><i class="fa fa-fw fa-home"></i>Home</a> 
	<p>SKYINSURANCE</p>
    </div>
          <br>
<div class="container">
<div class="imgcontainer">
    <img src="http://imgs-info.ru/2019/09/15/fullsizeoutput_5a.md.jpg" alt="Logo" class="avatar">
  </div>		
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">
				
											
					<div class="form-group">
						<label for="name">Email</label>
						<input  id="txtHint" type="text" name="email" placeholder="Your Email" onkeyup="showHint(this.value)" required class="form-control" />
						<p><span></span></p>
					</div>	
					<div class="form-group">
						<label for="name">Password</label>
						<input type="password" name="password" placeholder="Your Password" required class="form-control" />
					</div>	
					<div class="form-group">
						<input type="submit" name="login" value="Login" class="button" />
					</div>
                    <div class="form-group" >
                    <input type="button" value="Admin ? Login Here" class="button" onclick="window.location.href='adminlogin.php'"/>
                    </div>
				
			</form>
			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
		</div>
	</div>
</div>