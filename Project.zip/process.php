<?php
session_start();
$rndno=rand(100000, 999999);//OTP generate
$message = urlencode("otp number.".$rndno);
$to=$_SESSION['email'];
$subject = "OTP";
$txt = "Your verification code is: ".$rndno."";
$headers = "From: skyinsurance" . "\r\n" .
"CC:skyinsurance";
mail($to,$subject,$txt,$headers);
$_SESSION['otp']=$rndno;
header( "Location: otp.php" ); 
?>