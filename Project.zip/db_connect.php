<?php
/* Database connection start */
$servername = "localhost";
$username = "id11022541_sky";
$password = "harsh1603";
$dbname = "id11022541_skyinc";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>