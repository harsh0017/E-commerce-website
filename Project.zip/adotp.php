<?php

include_once("db_connect.php");
session_start();
$error = false;
if (isset($_POST['signup'])) {
	$email = mysqli_real_escape_string($conn, $_POST['email']);

	if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {

		$error = true;

		$email_error = "Please Enter Valid Email ID";

    }

    if (!$error) {
        $_SESSION['email']=$_POST['email'];
          $rndno=rand(100000, 999999);//OTP generate
           $message = urlencode("otp number.".$rndno);
               $to=$_SESSION['email'];
            $subject = "OTP";
                $txt = "Your verification code is: ".$rndno."";
               $headers = "From: skyinsurance" . "\r\n" .
               "CC:skyinsurance";
              mail($to,$subject,$txt,$headers);
              $_SESSION['otp']=$rndno;
              header( "Location: aotp.php" ); 

    }

}

?>

<script>

function showHint(str) {

    if (str.length == 0) { 

        document.getElementById("txtHint").innerHTML = "";

        return;

    } else {

        var xmlhttp = new XMLHttpRequest();

        xmlhttp.onreadystatechange = function() {

            if (this.readyState == 4 && this.status == 200) {

                document.getElementById("txtHint").innerHTML = this.responseText ;

            }

        }

        xmlhttp.open("GET", "gethint.php?qa=" + str, true);

        xmlhttp.send();

    }

}

</script>

<html>

<head>

	<title>Admin registration</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/nav.css">
	<link rel="stylesheet" href="css/landing.css">

</head>

<style>

body {

  font-family: Arial, Helvetica, sans-serif;

  background-color:white;

}



* {
  box-sizing: border-box;
}



/* Add padding to containers */

.container {
  padding: 16px;
  margin: auto;
  width:400px;
  background-color: white;
}



/* Full-width input fields */

input[type=text], input[type=password] {

  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  border-radius: 50px;
}



input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}



/* Set a style for the submit button */

.registerbtn {

  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
  box-shadow: 4px 4px 8px grey;
  border-radius: 50px;
}



.registerbtn:hover {
  opacity: 1;
}



/* Add a blue text color to links */

a {
  color: dodgerblue;

}
/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}

</style>
<div class="navbar">
   <?php
   echo '<div class="dropdown" >
   <button class="dropbtn">Sign-up 
     <i class="fa fa-caret-down"></i>
   </button>
   <div class="dropdown-content">
     <a href="registernew.php">User</a>
   </div>
 </div>';
      echo '<div class="dropdown" >
      <button class="dropbtn">Login 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="login.php">User</a>
        <a href="adminlogin.php">Admin</a> 
      </div>
    </div>';
	?>
  <a href="aboutus.php">Aboutus</a>
  <a href="contactus.php"><i class="fa fa-fw fa-envelope"></i>Contact</a> 
  <a class="active" href="https://skyinc.000webhostapp.com/"><i class="fa fa-fw fa-home"></i>Home</a> 
	<p>SKYINSURANCE</p>
    </div>

<br>
<br>
<div class="container">
<h2>Admin Sign-Up</h2>	
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="signupform">
					<div class="form-group">

						<label for="name">Email</label>

						<input type="text" name="email" placeholder="Email" onkeyup="showHint(this.value)" required value="<?php if($error) echo $email; ?>" class="form-control" />

						<p><span id="txtHint"></span></p>

						<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
					</div>
					<div class="form-group">
						<input type="submit" name="signup" value="Sign Up" class="registerbtn" />
					</div>
			</form>
			<span class="text-success"><?php if (isset($success_message)) { echo $success_message; } ?></span>
			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 col-md-offset-4 text-center">	
		Already Registered? <a href="adminlogin.php">Login Here</a>
		</div>
	</div>	
</div>

