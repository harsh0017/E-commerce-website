<!DOCTYPE html>
<html>
<head>
<title>landing page</title>
<?php
include_once("db_connect.php");
session_start();
if (isset($_POST['logout'])){
	session_destroy();
	header("Location: index.php");
}
?>
<style>
	body{
		margin:0;
	}
	
	#main{
		width:100%;
		height: 100%;
		float: left;
		
}
	#logo{
		float:left;
		width:100%;
		height: 100%;
		font-size: 20px;
		background-image: url("http://3ug0rc392q8g35229v3vvbxp.wpengine.netdna-cdn.com/wp-content/uploads/2016/02/Header-Background-Image.png");
		
	}

	#menus{
		float:left;
		width: 100%;
		height: 50px;
		background-color: beige;

	}

	#gallary{
		float: left;
		width:100%;
		height: 250px;
		background: lightgray;

	}

	#features{
		float: left;
		width:100%;
		height: 250px;
		background:red;
	}

	#menus ul{
		margin:0;
		list-style: none;
		padding: 0;
		height: 100%;
		display: inline;
		float: left;
		width: 100%;

	}

	#menus ul li{
		width: 10%;
		float: left;
		height: 100%;

	}
	#menus ul li a{
		width: 100%;
		float: left;
		text-align: center;
		text-decoration: none;
		font-size: 19px;
		font-weight: bold;
		color:white;
		padding: 14px 0;
		background:black;
		font-family: serif;
	}
	#menus ul li a:hover{
		background: white;
		color:black;
    }
    .formd{
        margin:50px 50px;
        padding:50px;
    }
    .button {
  background-color:black;
  color: white;
  border-radius: 50px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 25%;
  box-shadow: 4px 4px 8px grey;
}
</style>
</head>

<body>

	<div id="main">


		<div id="logo">
			<h1 align="center" style="color: bisque;" >SKY INSURANCE </h1>

		</div>



		<div style="background-color:black;" id="menus">
			<ul>
				<li><a href="">HOME</a></li>
				<li><a href="aboutus.html">ABOUT US</a></li>
                <li><a href="">CONTACT US</a></li>
                
                

			</ul>
		</div>
  <div >
	  <form class="formd" method="post">
        <h2 class="text">Welcome Admin <?php echo $_SESSION["user_name"];?></h2><br> 
        <input type="submit" name="logout" value="Logout" class="button" />
      </form>
  </div>
</div>



</body>
</html>