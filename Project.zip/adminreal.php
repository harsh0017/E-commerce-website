<?php

include_once("db_connect.php");

session_start();

$error = false;

if (isset($_POST['insert'])) {
    $name = $_POST['pname'];
	$price =$_POST['price'];
	$type=$_POST['type'];
	$image=$_POST['link'];
	$description=$_POST['pdesc'];
	if ($type == "Health") { 
    if(mysqli_query($conn, "INSERT INTO products(pname,price,pdesc,image) VALUES('" . $name . "', '" . $price . "', '" .$description. "', '" .$image. "')")) {
		$success_message = "Successfully added in health database!";} 
}
	elseif ($type == "Vehicle"){
	if(mysqli_query($conn, "INSERT INTO vehicle(pname,price,pdesc,image) VALUES('" . $name . "', '" . $price . "', '" .$description. "','" .$image. "')")) {
			$success_message = "Successfully added in vehicle database!";	
	}
} else {
if(mysqli_query($conn, "INSERT INTO term(pname,price,pdesc,image) VALUES('" . $name . "', '" . $price . "', '" .$description. "','" .$image. "')")) {
	$success_message = "Successfully added in term insurance database!";
}
}
}

?>

<!DOCTYPE html>

<html>

<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/landing.css">
	<link rel="stylesheet" href="css/main.css"> 
	<link rel="stylesheet" href="css/newnav.css"> 
</head>
<body>
<?php
include_once("navs/allnav.php");
?>
<div id="nav">

<ul>
    <li><a class="active" href="adminreal.php">Insert</a></li>
     <li><a href="messages.php">Messages</a></li>
  </ul>
</div>
<div class="container">
<h2>Insert Insurance Policy</h2>	
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="insertform">
					<div class="form-group">
						<label for="name">Insurance Name</label>
						<input type="text" name="pname" placeholder="Enter Name for insurance" required value="<?php if($error) echo $name; ?>" class="form-control" />
						<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>
                    </div>	
                    <div class="form-group">

						<label for="name">Price</label>

						<input type="text" name="price" placeholder="Enter a price" required value="<?php if($error) echo $name; ?>" class="form-control" />

						<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>

					</div>
					<div class="form-group">

<label for="name">Image</label>

<input type="text" name="link" placeholder="Enter a image link" required value="<?php if($error) echo $name; ?>" class="form-control" />

<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>

</div>

                    <div class="form-group">

						<label for="name"></label>

						<textarea rows="4" cols="50" name="pdesc" placeholder="Enter a description for product" required value="<?php if($error) echo $name; ?>" class="form-control" /></textarea>

						<span class="text-danger"><?php if (isset($uname_error)) echo $uname_error; ?></span>

					</div>
					<br>
					<div class="form-group">
					<select name="type">
                        <option value="Health">Health</option>
                        <option value="Vehicle">Vehicle</option>
                        <option value="Term">Term</option>
                      </select>
					  </div>
  



					<div class="form-group">

						<input type="submit" name="insert" value="Insert" class="registerbtn" />

					</div>

				

			</form>

			<span class="text-success"><?php if (isset($success_message)) { echo $success_message; } ?></span>

			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
			<span class="text-danger"><?php if (is_null(mysqli_error($conn))) { }else{ echo mysqli_error($conn);}?></span>

		</div>

	</div>





            