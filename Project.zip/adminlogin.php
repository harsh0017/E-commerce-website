<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['login'])) {
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);
	$result = mysqli_query($conn, "SELECT * FROM admin WHERE email = '" . $email. "' and pass = '" . md5($password). "'");
	if ($row = mysqli_fetch_array($result)) {
		$_SESSION['user_id'] = $row['aid'];
		$_SESSION['user_name'] = $row['user'];
		$_SESSION['emailid'] = $row['email'];
		$_SESSION['admin']=$row['aid'];
		header("Location: adminreal.php");
	} else {
		$error_message = "Incorrect Email or Password!!!";
	}
}
?>
<head>
	<title>Admin Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/landing.css">
</head>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-radius: 50px;
}
input[type=text]:focus, input[type=password]:focus {
background-color: #ddd;
outline: none;
}
.button {
  background-color:black;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  border-radius: 50px;
  box-shadow: 4px 4px 5px black;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  margin: auto;
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 300px;
  height: 300px;
  border-radius: 50%;
}
.container {
  margin: auto;
  padding: 16px;
  width:400px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
<?php
include_once("navs/adminnav.php");
?>
<div class="container">
<div class="imgcontainer">
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABqlBMVEX///8AAACrq6saGhr///4YGBgbGxv///0ICAj8//+BgYGFhYX//f8UFBT8/Pz5///t7e1qamrd3d12dnZsbGw80/A/Pz8prOR7e3tra2uioqL29vY91/ElpuDHx8cRERHp/P1Gqtgeo9gstOY5ze5dXV0int5TU1Oz3+sYDgwpano3yO1JSUnU1NS8vLw3NzfF6PY0v+srseYnJyeVlZUXEQcwdn8ubn0lYnhF4vkxueYAAAkjod7AwMCzs7MaktwRec8TNFHY8vkYos8XEBUYCAAaAwsRFwAbEQA9bm42eoElX3kuXGsYERgkFhsACgBX9P00dYtNxs8MGyxIp609i6wRNT0aPVM9hpFCvN9Av9kwm6oZRE8WKTcVEyYPFSBKtcQ/qsw0lcUvfacPHBMsbIsPMEEjUFQhT2UeNjkLJChCrMQDFh80gZwui8I/mbMMHgQhYYYwk88ncqQuidAgVWoZRmkoMkKVusmDnqo9OkM9NSssJSANjeMofcIlWIkhaaYOetceb7kRM1kfSHwJJD13tdCKxdZvtOV9xuW35f2P0+Gq1ujG/P8iONcbAAAPGklEQVR4nO2ci1vb1hXAdZH1CpL8jOXiCPmBX4mNjW111IhHbaBZU5d2rGPOoAwCWZYAWR7Num4kTbc8nMf/vHOvLD+AdjTtPtn57i/EloW/fP7l3Mc5V1dmGAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqGMGuqI/tuUHmp0Yuz/xYTPbTubFPp/EXZbjaAyPsSy7PKqubK6apormBx56GGapv3kvCInnLPd95CjT66uKmbOVJZZHgXclnOYQLzx208//BT/fPphj9/gvwNcPsns7Cz+2+EacHn22uw316591vx8LeK2WAdVVYtK7tMvPvqC/JzgEuYiZmoKfghXesw41IAkUAZqSS35pcEZQ9ILMfOIm/vdKS9H7aLjdaYacbPtMLWyBo5aY91EE4zktliPlLH6ly9Ox67r6ETPDuDMCb2k4wduSU23LE375pNPwlHZOyyKKhNA3OrvT7rZev1qAzFstboB7EYwWQZLXUt+tb2H5hlZdtusjwgy/3Dpoy/6DU8EsNtGT0aw44c7oKZpul7W9PhG00gxXkkalhhCEKPo89wfP7r0I83zSjeCUyBY6+jBTzlZm+n6EUMNDK3DFRYN0TBjM4aaa7/rC+Bg/4MDIthq7bRa13EYWziAWPG0oB5fZ9G420KDqCojhJvmbx3DE8OLPYpe/9OHm1tff719e/PyXXt0wS20rPX7AQ1LnzW5StRtp5N4mEnE5v78UZ/fxf7B80rr8tbq6jK3t7cH6crq+uzODIiBI4wtSaLnGOrWrmGiBbeFTiMJ/rnc5hmCU6T3HX5tcApkmqIiwqNy9erBfqtWLtuDZzd+MM5oln6LW8u4rXMGshCY49CfTg4xnQa6uWI2UXF80qcysm+yWkQGb27eIbO75nRAhxsGhwrM0BWHHkFmxtHe1nV7DuwJYna2miwKT9uzmyDAf8d8HrHLW3f7RxiHxE0TBV22ORMP44lynPjlxUtTV/r1Zqau3NnKcaga7bwLG4LnBOKa63c1rdNCdT2tN8Avnd43ueGbKRwWELf95/7+R7h+k+PQ5KlWV4A3397RNXuax6lawgLD3YOrqMoMUzIzQN5Q/nJx6lJPED/OLuN+pQ4qqkQx95nmGOoJLZ3WYZhRrlYYYWhymZMUEI/uXOwvI2au3G1+gsYYMmf2Ay8XkJn7yumCVgJaaNraRSYkpII7H/88BOfMv/bl2DAPXrm1Z6bs8HUVVWLrZUJruU2YHUgbBdJWOrFhiilJEDyuGfwvfAq3cgi5px0+MJza+XoPL0YEJhYGYjg9ARNCYM5c3nUEIYBpa7/JzQVgNHLr85+DKtq+fb2viJi63FxL4TEIoWI3EVPJ4lWVgSAuX9OcEFrpxd0tDhJSYXhKijOQi4p5ecppoTO11h+a0K+iFYVloWZ3mEc8y4o+PNjcbNh2OITpe4bCR2E6GWZD+PDs9h27hUINUds5YJHs9XEc218ujCGWZ1HBy8Cbd20/zBHUFGMufvZzITAZY3lzasYpdO/OcUWY5/MiGM1331VALGtUohKTN5dvdAXTtxSz6OJnPx9eKYBYdJesUdRqrZmv5gw8kvoqaKDiG4N+WIB5PbiW23cEF2+YLElIhxwJ0lNuvYVXKJJgeCiKETIVBgYLPtVe7B1HK/tOBNMwzAxlQnoCWfBVuOaXV2agxK3NzByaYrAzgaunigWBGRd7hvdMbts3vBOhgyDJDCTVB3dmcHVbqx2uGRmGTODq6XJIYPxirmO4eLRlDnNC2kUQZFkIK7nPWskWXoS5u8Z9DtnLmcUeTAuVnHGD+N1ffKQoMGMOfwwJk+hz8S5ZoSjv3M6hgaankoyUHApCFJkHR+nF9OJi+sjg0TQzxOlaP5CyiM3NVrlWK5dbt5onpjgVjy+di0qQe2/cxwFcvL/BQXMesrL+R8HX2/iVQ7JIWNtv/i082LkCfgTRglEXpkPDvIcjeH/xwRqPAvJQLXL/NFXUvF3T8GJoAyra6b7fBMZFVJm0jydhSDpaxNxfN9EFVz7puxKtNM1ZvMaULM+ursEIggvgyWokYyDkn+40RvWfB8qtNDGEhJQb2qWLs1lArLGbxPX7zvreXMiZBXw+e+InjkHEdkJ4pHDQW1V7mWpEEDK55U17lekQ4aT7dMVQRQcr+7gPLi5ucGZeHS1DQSjMceZXmpbU9Pg1k0cRqNsHDccRbzy6T0L4YJssVY0UksCEcuZGnKxiNzZyLMoXBlZfAhnEL9uCxw8/zon+UZnrHSRV8CFT3C/jVUJL/+aAX0Yf9OqGQggZ7MGjIzzMHMMwwyLfUBe9ZyB5BOhn3EHCOjy8cXjjxgbU+AaqXBibnp4eGy8ikWO5v+/vPwAeH+3tQUI6aoaMR5CileXcjV1R3F4zDMWEop7nOhuBoOAHOMNsGsvo22/RciXqHZkhpgtkmNMI/ePbtSZrbl81c9zyco7jFIidw94ex0HN6wvgFGfkDFXcTj0pNB+dY83wd999Fw6Hi98VgUqxH34PBQII6ivB6/ZHfgc8TAAMEStWgfEeFwgRIBjhWWwYYDwjNpJ2CU5jw65YBP7AY9AhFMSGhVFYuvgxfPOOYSduwfw/88GOYihkGwZGLCHtQXLPjqHTMitzzw74kCNoGw7d1d6fhw9xhhPAyIXM3L37Dw7CjuAHQX6Idli+Iz6IYbAzsEQi+fWjxYdbRaIHgqGUwY68oRoSucq4LRiMZMR7R/cghsTP7w9VOEhIR52AyBope24AKtvrCu/vCPrzUBaOfAhxGcjyHb9g8F9bj25yfmiffgzPDdvmrncA6tqKouQ7gv6Va4v35lIkgH5/WOH4odvc9XPBK/nziDXsCSKYER8cP9jO24IphR/GzV3vQsbginYKE15/fPz4ZoUI+oucUhztqbAD3kAMgw0ZP//18cPjh49MiJ8/lTFG4lraOYAoXYDBBhv6xUcPj4+fiBl/KuWvsCjEjHg+08VXUYw8KGbmHhwfL32/HQZDmCmG6W6DX8oYYmGOCBUPHi8tLT3eqoAh5GvV9ySAGDVsKOFQiL/5EAyXPjZSKRhmhm8b8C9hErFKCrrhMTaEjpjiWJgp3p8QAn6R92fEJ8QQOmKKN/Juf6RfGR8q+sPbj3E/XPrhWSWUGvmE9BTVvL/ybOmHpae4I4rzC6FRW+T+n0QDfmPj8dJTbPgIBXzv0UzRZQEdfA9+T5d+WEdjjDA6l3vPTRU1P4Z++PTpI27FzwzzHtJ3pYDY3BMw/MG+7j06lwrPT2SNewaN9N9XDXzDyMguAv8EUXSw/Z+nT6AsDAjSe+jHkPR0+8kzE1/z9r6PjZTxqOEcu3XAcVFBfT8NSXrKjsA24F+CX2SN/HuVcJ8kgEZv18XPgayejv4i908THd770n4tAu9X3XsC++6nsw09J448fVmP29nBGZ9Yte/dIjsSVedNzo5EKCtkSZZleJIlr+CVZVWQyPZpSYZXgiDJKt66IEByLguM4HoGi2XUzu7m3hmycd0+Zx8RQfxWVYXCySt5sQEcwR8ZH3gEeMK/EoglnAVjRoZTjORxt9JSe1bneycjYSevF1t2HvBjDNxUOGRkMMSncIQBkHZ7v5SayeRJmvJBBvBPRBlmOp/Jw5jpg9fVQD6T8VUzmRDe4A2v8R0LghB7/vLlc0KpHifPbyBg0ovnd15Au/S+gBNej1R6/vxOXZLcvkehgBR7kiuKhigaqOKDFNvAl5UK8HQhAA++cXiAmd6P8F5n3PtiO7qllTUrnciWEklNT1tt+Bdi8XJyJwYRbGu6XvdIbUtLZL2S2x1xAZJNHrfAsMJVKiIPElBEiCFycRSNQxoj+sbxlWAwNLChQAwbCfxNNHoj+woOGlrihVeS6pZugZlXemlpelaQ4ul0uuR+sRwSWXu/QVhBE9GgqBSxISvi7+XpGZJ9JX6RGHo8grdeL8W1xOt63YsN39brdeicbxIamEE3bOlaoi3VE2UtUXL/dkQIHUsudWJDXD6gKL6/EAWiPNc1hBNiEAzFCwz5wDJuktAE4bCU0BJevOlWZdoNTWu0YawBQ23HW9KxoeuLAQFDCfPkVgJiGEA88o0hCNkCvsuwZwjOUb8h9u45cAxfWVo8xkiSIEM3LCf1eEz2tsGwEcOPiZLrd3ZPIlQtKjzTMfRBDAPY0AhN9Bvy4FyNiKcNhVIjqcXjbehsdcu63kpbdYkYJrI72lAYVhGazygo2jXksSHLckXohn0xVDiukjojhp5XibKla22P5M2mrdev01aWgbEU3GbiZfcNVTycoEBExHPBgCHPcwq+2dcxVDLQXxX2jBiCoY57nyS9SSSyWT3xwjbUyDdKuG1oX99lJsi95/2tlAtXWLYSVkTH0AjipsujM/phohx/G4t5BellsvH2bSL5UsLzYQ0Mk+UhMMTDSb6oKJmOIbzGI42SyShKPtNnmFJ5hT0jhp6spcNYKniEGMwVcXwDQ0xq6zpIau34EBhOIJ4zDBbv/SGGMP9zKjYcF8UQzPDOfCj6cQIwYLijQZeThGyi3IjBa+EtNNcy/pahOtO29NcQv9cJXS95XE1MVSYocpVikcdfXxI2YPyscJC8gGF+AVpunyGcjaKTMbSyUFa8svR0u91+w2QtzYrv4LPetlV+3dYakAzAjC+7+h0LalFBC2o0D48QQ9ZAZPbH/RBmkTGY/7qGfnIj0ClD2ZOFnCahJ9pMO623Y7EX0DihlWqvX+iNtwnNKnndzdp8COGMDVJqP1Ox76aYwE0X8m+EChmEIgU45YsglLHf3NvUDalpIwvJzKvdRqKhp597d6zEa48MA2ojBoftN/d33+4mjrJuG05OTuK77ScnC0wBjifJxWvyEn4BZwJR/A5ygsHv6F3cVuulEoygnliJUJfhIQY5KTx566VsPVaq41/FPO4npmdzuiJWB89D94IiVyABwvU+1LwwJ5JbS2SPhBc2PAyugF0dS7tLL2rfeoyzNqOqvYPOr9TBdSivrMoqXrsQGLw8I8l4NQMOvXipQ5AFFWoQxl3Dc6EOHPVeQSnPYC+IGA4YXqACLbxG5cXxhSoSfzGYMAKGFAqFQqFQKBQKhUKhUCgUCoVCoVAoFAqFQqFQKBQKhUKhUCgUCoVCoVAoFArlV+W/jV64g+KgIEQAAAAASUVORK5CYII=" alt="Logo" class="avatar">
  </div>		
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">
				
											
					<div class="form-group">
						<label for="name">Email</label>
						<input type="text" name="email" placeholder="Your Email" required class="form-control" />
					</div>	
					<div class="form-group">
						<label for="name">Password</label>
						<input type="password" name="password" placeholder="Your Password" required class="form-control" />
					</div>	
					<div class="form-group">
						<input type="submit" name="login" value="Login" class="button" />
            <div class="form-group">
                    <input type="button" value="Register" class="button" onclick="window.location.href='adotp.php'"/>
             </div>
				
			</form>
			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
		</div>
	</div>
</div>