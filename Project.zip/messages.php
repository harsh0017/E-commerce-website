<?php
session_start();
include_once("db_connect.php");
?>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/newnav.css"> 
</head>
<style>
.contentcolumn{
  margin-left:320px;
}
a{
  color: blue;
}
</style>
<?php
include_once("navs/allnav.php");
?>

</div>
<div id="nav">

<ul>
    <li><a class="active" href="adminreal.php">Insert</a></li>
     <li><a href="messages.php">Messages</a></li>
  </ul>
</div>
<!DOCTYPE html>
<html>
<title>Inbox</title>

<h1 class="contentcolumn">Inbox</h1>
<br>
<?php
$result=mysqli_query($conn,"SELECT * FROM message;");
if ($result) {
    while($row = mysqli_fetch_assoc($result))
    {
      $name=$row['name'];
      $sem=$row['email'];
      $mes=$row['message'];
      $date=$row['DateInserted'];
      echo '<div class="contentcolumn"><h3>From:'.$name.'</h3>
              <h5>Date&Time:'.$date.'</h5>
              <h5>Email:<a>'.$sem.'</a></h5>
              <h5>Message:'.$mes.'</h5></div>';
    }
  }
   else {
      $error_message = "Can't Fetch data. Try again later!!";
  }
?>
</html>
<!--<input type="hidden" value="'.$name.'"  name="name" id="name"/>
               <input type="hidden" value="'.$price.'" name="price" id="price"/>-->