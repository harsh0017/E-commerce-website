<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="css/newcard.css">
  <style>
.parallax {
  /* The image used */
  background-image: url("https://images.wallpaperscraft.com/image/road_sunset_horizon_marking_118582_1920x1080.jpg");

  /* Set a specific height */
  min-height: 500px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
  <title>About Us</title>
</head>
<body>
  <div id="main">
    <div id="top">
        <h2 id="logo">SKY INSURANCE</h2>

          <div id="tr">
            
          <ul>
          <?php
			  if(!isset($_SESSION['user_name'])){
				echo '<li><a href="registernew.php">Sign Up</a></li>';
				echo '<li><a href="login.php">Login</a></li>';
			  }
			  else{
				$username=$_SESSION['user_name'];
				echo '<li>'.$username.'</li>';
        echo '<li><a href="mypurchase.php">My Products</a></li>';
        echo '<li><a href="logout.php">Logout</a></li>';  
          
			  }
			  ?>
              <li><a href="contactus.php">Contact Us</a></li>
              <li><a href="aboutus.php">About Us</a></li>
              <!-- <li><a href="">AdminLogin</a></li>-->
              <li><a href="https://skyinc.000webhostapp.com/">Home</a></li>
           </ul>    
          </div>
      </div>
      
      <div class="parallax"><br><iframe align="center" width="600" height="320" src="https://www.youtube.com/embed/SiIIUHB78kI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br></div>
                        <div class="box">
                            <div class="card">
                              <div class="imgBx">
                                  <img src="http://imgs-info.ru/2019/10/14/paritoshdhotre.jpg" alt="images">
                              </div>
                              <div class="details">
                                  <h2>Paritosh Dhotre<br><span>Actuary</span></h2>
                              </div>
                            </div>
                          
                             <div class="card">
                               <div class="imgBx">
                                  <img src="http://imgs-info.ru/2019/10/14/harshjain.jpg" alt="images">
                               </div>
                               <div class="details">
                                  <h2>Harsh Jain<br><span>Claims Adjuster</span></h2>
                                </div>
                             </div>

                             <div class="card">
                               <div class="imgBx">
                                  <img src="http://imgs-info.ru/2019/10/14/anuragkothari.jpg" alt="images">
                               </div>
                               <div class="details">
                                  <h2>Anurag Kothari<br><span>Insurance Sales Agent</span></h2>
                                </div>
                             </div>

                             <div class="card">
                               <div class="imgBx">
                                  <img src="http://imgs-info.ru/2019/10/14/siddheshpawar.jpg" alt="images">
                               </div>
                               <div class="details">
                                  <h2>Siddhesh Pawar<br><span>Insurance Investigator</span></h2>
                                </div>
                             </div>
                       

                  </div>
</div>
  

</body>
</html>