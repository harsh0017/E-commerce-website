<?php


$b[] = "dhiraj@er.com";
$b[] = "bh@er.com";
$b[] = "tr@er.com";
// get the q parameter from URL
$q = $_REQUEST["qa"];

                
if (filter_var($q, FILTER_VALIDATE_EMAIL)) {
  
 

$hint = "";

// lookup all hints from array if $q is different from "" 
if ($q !== "") {
    $q = strtolower($q);
    $len=strlen($q);
    foreach($b as $name) {
        if (stristr($q, $name)) {
            if ($hint === "") {
                $hint = "Already registered";
            }
        }
    }
}

// Output "no suggestion" if no hint was found or output correct values 
echo $hint === "" ? "" : $hint;

/// ph mail otp
}
else {
    $hint = "Invalid Email";
 echo $hint ;
}
?>