<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['buynow'])) 
{
if(!isset($_SESSION['user_name']))
{
  echo '<script>
  alert("Please Login to continue.");
  </script>';
  }
  else {
    $emailid=$_SESSION['emailid'];
    $result=mysqli_query($conn, "SELECT email from purchased where email = '" . $emailid. "' and pname = '" .$_POST['name']. "'");
    if ($row = mysqli_fetch_array($result)) {
      echo '<script>
  alert("You have already purchased the product.");
  </script>';
    }
   
    elseif(mysqli_query($conn, "INSERT INTO purchased(email,pname,price,PurchaseDate) VALUES('" .$emailid. "', '" .$_POST['name']. "', '" .$_POST['price']. "',UTC_TIMESTAMP())")) {
      echo '<script>
      alert("Item Purchased successfully!");
      </script>';
       /* header("Location:afterbuyno.php");*/
    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/landing.css">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/nav.css">
   <!--  <link rel="stylesheet" href="css/main.css"> -->
    <link rel="stylesheet" href="css/product.css">
    <!--<link rel="stylesheet" href="css/landingtwo.css">-->
</head>
<style>
  body{
    background-color:rgb(33,33,33);
  }
  </style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/nav.css">
<div class="navbar">
    <?php
    if (isset($_SESSION['admin'])){
      $username=$_SESSION['user_name'];
      echo  '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="adminreal.php">Dashboard</a></div>
    </div> ';
 }
 elseif(isset($_SESSION['user_name'])){
      $username=$_SESSION['user_name'];
      echo '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="mypurchase.php" >My Products</a></div>
    </div> ';
      }
    else{
      echo '<div class="dropdown" >
      <button class="dropbtn">Login 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="login.php">User</a>
        <a href="adminlogin.php">Admin</a>
      </div>
    </div> 
      <a href="registernew.php">Signup</a>';
      }
	?>
  <a href="aboutus.php">Aboutus</a>
  <a href="contactus.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a class="active" href="https://skyinc.000webhostapp.com/"><i class="fa fa-fw fa-home"></i> Home</a> 
	<p>SKYINSURANCE</p>
    </div>


<?php
/*     CALLING PROCEDURE    */
$result=mysqli_query($conn,'CALL allproducts()');

if ($result) {
    while($row = mysqli_fetch_assoc($result))
    {
      $name=$row['pname'];
      $price=$row['price'];
      $des=$row['pdesc'];
      $image=$row['image'];
      // <button>'.$text.'</button>
      $text="Buy now";
        echo '<div class="pcard">
        <img src="'.$image.'" style="width:100%">
              <h3>'.$name.'</h3>
              <h2 style="text-align: center;" class="price">'.$price.'&#8377;</h2>
              <h4 style="text-align: center;">'.$des.'</h4>
              <form role="form" action="'.$_SERVER["PHP_SELF"].'" method="post" name="buynowform">
               <input type="hidden" value="'.$name.'"  name="name" id="name"/>
               <input type="hidden" value="'.$price.'" name="price" id="price"/>
               <input type="submit" name="buynow" value="Buy Now"/>
               </form>
              </div>';
              
      
    }
  }
   else {
      $error_message = "Can't Fetch data. Try again later!!";
  }
?>
</html>