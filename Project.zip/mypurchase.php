<?php
session_start();
include_once("db_connect.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/landing.css">
   <!--  <link rel="stylesheet" href="css/main.css"> -->
    <link rel="stylesheet" href="css/product.css">
    <!--<link rel="stylesheet" href="css/landingtwo.css">-->
</head>
<body>
<?php
include_once("navs/allnav.php");
?>
<?php
$email= $_SESSION['emailid'];
$result=mysqli_query($conn,"SELECT * FROM purchased where  email = '" . $email. "'");
if ($result) {
    while($row = mysqli_fetch_assoc($result))
    {
      $name=$row['pname'];
      $price=$row['price'];
      $dop=$row['PurchaseDate'];
      // <button>'.$text.'</button>
      $text="Buy now";
        echo '<div class="pcard">
              <h3>Insurance name:'.$name.'</h3>
              <p class="price">Bill amount:'.$price.'&#8377;</p>
              <p class="price">Purchase Date:'.$dop.'</p>
              </div>';
              
      
    }
  }
   else {
      $error_message = "Can't Fetch data. Try again later!!";
  }
?>
</html>