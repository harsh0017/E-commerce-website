<?php
session_start();
include_once("db_connect.php");
if (isset($_POST['login'])) {
    $username=$_POST['email'];
    $password=$_POST['password'];
    $result=mysqli_query($conn,"SELECT * FROM sqldemo WHERE email = '$username' AND pass = '$password';");
    $row=mysqli_fetch_assoc($result);
     $count=mysqli_num_rows($result);
    /*$result=mysqli_query($conn,"SELECT * FROM users WHERE email = '$username';");*/
    if($count>0){
        header('location:injection.php');
      }
	 else {
		$error_message = "Incorrect Email or Password!!!";
  }
}

/*
SELECT * FROM users WHERE email = '$username';
SELECT * FROM users WHERE uid = '$username'
' OR '1'='1 DELETE FROM users WHERE uid=1;
*/

?>

<style>
body {font-family: Arial, Helvetica, sans-serif;}

table{
  text-align:center;
}
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-radius: 50px;
  
}
.button {
  background-color:black;
  color: white;
  border-radius: 50px;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  box-shadow: 4px 4px 8px grey;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  margin: auto;
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 300px;
  height: 300px;
  border-radius: 50%;
}

.container {
  margin: auto;
  padding: 16px;
  width:400px;


}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>

<div class="container">
<div class="imgcontainer">
    <img src="http://imgs-info.ru/2019/09/15/fullsizeoutput_5a.md.jpg" alt="Logo" class="avatar">
  </div>		
	<div class="row">
		<div class="col-md-4 col-md-offset-4 well">
			<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" name="loginform">
					
					<div class="form-group">
						<label for="name">Email</label>
						<input type="text" name="email" placeholder="Your Email" required class="form-control" />
					</div>	
          <div class="form-group">
						<label for="name">Password</label>
						<input type="text" name="password" placeholder="Password" required class="form-control" />
					</div>
					<!--<div class="form-group">
						<label for="name">Password</label>
						<input type="password" name="password" placeholder="Your Password" required class="form-control" />
					</div>-->	
					<div class="form-group">
						<input type="submit" name="login" value="Login" class="button" />
					</div>
          
			</form>
      <form method="post">
      <div class="form-group">
						<input type="submit" name="fetch" value="Fetch Data" class="button" />
					</div>
          </form>
			<span class="text-danger"><?php if (isset($error_message)) { echo $error_message; } ?></span>
		</div>
	</div>
</div>

<!--<table >
<tr>
<th>Id</th>
<th>Username</th>
<th>Password</th>
</tr>
</div>-->
