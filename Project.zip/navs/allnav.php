
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/nav.css">
<div class="navbar">
    <?php
    if (isset($_SESSION['admin'])){
      $username=$_SESSION['user_name'];
      echo  '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="adminreal.php">Dashboard</a></div>
    </div> ';
    }
 elseif(isset($_SESSION['user_name'])){
      $username=$_SESSION['user_name'];
      echo '<div class="dropdown" style="margin-right: 10px;">
      <button class="dropbtn">'.$username.' 
      <i class="fa fa-caret-down"></i>
      </button>
    <div class="dropdown-content">
    <a href="logout.php">Logout</a>
    <a href="mypurchase.php" >My Products</a></div>
    </div> ';
      }
    else{
      echo '<div class="dropdown" >
      <button class="dropbtn">Login 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-content">
        <a href="login.php">User</a>
        <a href="adminlogin.php">Admin</a>
      </div>
    </div> 
      <a href="registernew.php">Signup</a>';
      }
	?>
  <a href="aboutus.php">Aboutus</a>
  <a href="contactus.php"><i class="fa fa-fw fa-envelope"></i> Contact</a> 
  <a class="active" href="https://skyinc.000webhostapp.com/"><i class="fa fa-fw fa-home"></i> Home</a> 
	<p>SKYINSURANCE</p>
    </div>

